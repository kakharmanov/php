<?php
    $mysqli = new mysqli("localhost", "root","root","register");
?>